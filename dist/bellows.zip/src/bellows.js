(function($) {
    function Bellows(element, options) {
        this.init(element, options);
    }

    Bellows.DEFAULTS = {
        singleNodeOpen: true,
        duration: 200,
        easing: 'swing'
    };

    Bellows.prototype.init = function(element, options) {
        this.options = $.extend({}, Bellows.DEFAULTS, options);

        this.element = $(element);
        this.current = null;

        this.element.find('.bellows__content').wrap($('<div class="bellows__content-wrapper" />'));

        this._bindEvents();
    };

    Bellows.prototype._bindEvents = function() {
        var plugin = this;

        this.element.on('click', '.bellows__header', function() {
            plugin.toggle($(this).parent());
        });
    };

    Bellows.prototype.toggle = function(item) {
        this[item.hasClass('bellows--open') ? 'close' : 'open'](item);
    };

    Bellows.prototype.open = function(item) {
        var plugin = this;
        var $content = item.find('.bellows__content-wrapper');

        if (this.options.singleNodeOpen) {
            this.element.find('.bellows--open').each(function() {
                plugin.close($(this));
            });
        }

        console.log(this.options)
        $content
            .velocity('slideDown',
            {
                duration: this.options.duration,
                easing: this.options.easing,
                complete: function() {
                    item.addClass('bellows--open');
                    $content.css('height', '');
                }
            });
    };

    Bellows.prototype.close = function(item) {
        var $content = item
            .removeClass('bellows--open')
            .find('.bellows__content-wrapper');

        $content.velocity('slideUp',
            {
                duration: this.options.duration,
                easing: this.options.easing,
                complete: function() {
                    $content.css('height', '');
                }
            });
    };

    Bellows.prototype._trigger = function(eventName, data) {
        eventName in this.options && this.options[eventName].call(this, $.Event('bellows:' + eventName, { bubbles: false }), data);
    };

    // BELLOWS PLUGIN
    // =========================

    $.fn.bellows = function(option) {
        return this.each(function() {
            var $this = $(this);
            var bellows = $this.data('bellows');

            if (!bellows) {
                $this.data('bellows', (bellows = new Bellows(this, option)));
            }
            if (typeof option === 'string') {
                bellows[option]();
            }
        });
    };

    $.fn.bellows.Constructor = Bellows;

    return $;
})(Zepto);
